# Token Insight Report — 使用指南

> 适用 IDE：Antigravity · Claude Code · Codex CLI · 以及任意支持终端的环境

---

## 目录

- [一、这个 Skill 能做什么](#一这个-skill-能做什么)
- [二、前置条件](#二前置条件)
- [三、在 Antigravity 中使用（推荐）](#三在-antigravity-中使用推荐)
- [四、在 Claude Code 中使用](#四在-claude-code-中使用)
- [五、在 Codex CLI 中使用](#五在-codex-cli-中使用)
- [六、直接运行脚本（通用方式）](#六直接运行脚本通用方式)
- [七、报告输出说明](#七报告输出说明)
- [八、常见问题](#八常见问题)

---

## 一、这个 Skill 能做什么

对本机所有 AI IDE 会话进行月度/周度效能审计，生成一份 Markdown 报告：

| 分析维度 | 内容 |
|----------|------|
| **Token 消耗** | 按数据源、按天、按会话分层统计（未缓存/缓存/输出） |
| **活跃时长** | 基于会话时间戳估算每个项目的实际开发时长 |
| **项目分布** | 自动识别各项目的时间占比 |
| **错误率** | 统计 AI 步骤失败率，估算无效工时 |
| **Prompt 样本** | 提取高活跃会话的用户输入，供认知诊断 |
| **RTK 节省** | 汇总命令行 Token 节省量 |

支持 6 个数据源，按精度从高到低：

```
🟢 Antigravity   — token_stats.db 精确统计 + transcript.jsonl 行为分析
🟢 Claude Code   — ~/.claude/projects/ 中的 .jsonl 事件解析
🟢 Codex CLI     — ~/.codex/sessions/ 中的 .jsonl 事件解析
🟡 Cursor        — state.vscdb composerData（无缓存 Token 数据）
🔴 Trae          — 仅 Turn 数量，Token 为估算值（8000/Turn 输入）
🔴 Trae CN       — 同上
```

---

## 二、前置条件

**Python 3.9+**（脚本依赖标准库，无需额外安装包）

```bash
python --version   # 确认已安装
```

**Skill 路径**（本文档假设 skill 安装在）：
```
d:\Temp\shell\quick-shell\.agents\skills\token-insight-report\
```

如果安装在其他位置，替换下文中所有对应路径即可。

---

## 三、在 Antigravity 中使用（推荐）

Antigravity 原生支持 Skill 系统，**只需用自然语言触发**，AI 会自动读取 `SKILL.md` 并执行完整流程。

### 3.1 自动触发

直接在对话框输入以下任意一种表达，Skill 会自动激活：

```
分析本月的 IDE 使用情况
生成 Token 用量报告
帮我做一份月度 IDE 复盘
这周用了多少 Token？
诊断一下我最近的 Claude Code 会话效率
```

Antigravity 识别触发词后，会：
1. 读取 `SKILL.md` 获取操作流程
2. 自动运行 `scripts/audit.py`（检测当前用户目录）
3. 将生成的报告写入**当前工作目录**
4. 读取报告内容并以结构化格式展示给你

### 3.2 指定参数触发

如果需要自定义分析范围，在对话中说明即可：

```
分析最近 7 天的 Token 使用，只看 Antigravity 和 Cursor 两个来源
```

```
帮我分析本月的 IDE 数据，数据目录在 C:\Users\myname\.gemini\antigravity
```

### 3.3 确认 Skill 已加载

在 Antigravity 中运行以下命令，确认 skill 出现在列表中：

```
/skills
```

应能看到 `token-insight-report` 已注册。

---

## 四、在 Claude Code 中使用

Claude Code 没有原生 Skill 加载机制，有两种方式让它使用本 Skill：

### 方式 A：通过 CLAUDE.md 引用（推荐）

在你的项目根目录或 `~/.claude/CLAUDE.md` 中添加：

```markdown
## Token Insight Report Skill

当用户要求分析 IDE 使用情况、Token 消耗、月度复盘时，
执行以下脚本并读取输出结果：

```bash
python "d:\Temp\shell\quick-shell\.agents\skills\token-insight-report\scripts\audit.py" --days 30
```

脚本会在当前目录生成 `token_insight_report_YYYYMMDD.md`，读取后以结构化报告形式呈现。
```

配置完成后，在 Claude Code 中说：
```
分析本月的 Token 使用情况
```
Claude Code 会按照 CLAUDE.md 中的指引执行。

### 方式 B：手动粘贴指令

在对话中直接发送：

```
请执行以下命令并分析结果：
python "d:\Temp\shell\quick-shell\.agents\skills\token-insight-report\scripts\audit.py" --days 30

执行完成后，读取生成的 token_insight_report_*.md 文件并输出报告。
```

---

## 五、在 Codex CLI 中使用

Codex CLI 支持通过 `AGENTS.md` 文件注入指令。

### 方式 A：通过 AGENTS.md 引用

在项目根目录的 `AGENTS.md` 中添加：

```markdown
## Token Insight Report

分析 IDE Token 使用情况时，运行：
python "d:\Temp\shell\quick-shell\.agents\skills\token-insight-report\scripts\audit.py" --days 30

完成后读取当前目录下的 token_insight_report_YYYYMMDD.md 并输出摘要。
```

然后在 Codex 会话中说：
```
帮我分析本月的 IDE Token 使用
```

### 方式 B：在对话中直接运行

Codex 支持执行 shell 命令，直接发送：

```
执行 python "d:\Temp\shell\quick-shell\.agents\skills\token-insight-report\scripts\audit.py" 并读取报告
```

---

## 六、直接运行脚本（通用方式）

不依赖任何 IDE，适合在终端、定时任务、CI 中使用。

### 基础用法

```bash
# 分析最近 30 天（报告输出到当前目录）
python audit.py

# 指定分析天数
python audit.py --days 7

# 指定 Antigravity 数据目录（自动检测时填入）
python audit.py --app-data-dir "C:/Users/yourname/.gemini/antigravity"

# 同时输出 JSON 原始数据
python audit.py --days 30 --json

# 只分析特定数据源
python audit.py --sources antigravity,cursor

# 指定输出目录
python audit.py --output-dir "D:/reports/"
```

### 可用数据源（--sources 参数）

| 参数值 | 对应工具 | 精度 |
|--------|----------|------|
| `antigravity` | Antigravity / Claude Code (via token_stats.db) | 🟢 HIGH |
| `claude_code` | Claude Code (.jsonl 事件) | 🟢 HIGH |
| `codex` | Codex CLI | 🟢 HIGH |
| `cursor` | Cursor IDE | 🟡 MEDIUM |
| `trae` | Trae 国际版 | 🔴 LOW |
| `trae_cn` | Trae CN | 🔴 LOW |

### 示例：只看 Antigravity + Cursor

```bash
python audit.py --days 30 --sources antigravity,cursor
```

### 设置为定时任务（每月 1 号自动生成报告）

**Windows 任务计划程序**（PowerShell）：

```powershell
$action  = New-ScheduledTaskAction `
    -Execute 'python' `
    -Argument '"d:\Temp\shell\quick-shell\.agents\skills\token-insight-report\scripts\audit.py" --days 30' `
    -WorkingDirectory 'D:\reports'

$trigger = New-ScheduledTaskTrigger -Monthly -DaysOfMonth 1 -At '09:00'

Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "TokenInsightReport"
```

---

## 七、报告输出说明

### 输出文件

```
<当前目录>/token_insight_report_YYYYMMDD.md    ← 主报告（每天唯一）
<当前目录>/token_insight_report_YYYYMMDD.json  ← 原始数据（--json 时生成）
```

同一天多次运行会**覆盖**同名文件（文件名只精确到日期）。

### 报告结构

```
# IDE Token Insight Report
> 分析周期 | 生成时间

## 1. 多数据源效能总览      ← 所有数据源对比表格
## 2. Antigravity 深度分析  ← 精确 Token 统计 + 项目时间分布 + 错误分析 + Prompt 样本
## 3. 其他 IDE 数据源摘要   ← Cursor / Trae 等可用数据源
## 4. RTK 命令行 Token 节省
```

---

## 八、常见问题

**Q: 脚本运行后提示 `token_stats.db not found`？**

确认 `--app-data-dir` 路径正确。默认自动读取 `C:\Users\<USERNAME>\.gemini\antigravity`，
如果你的用户名含特殊字符，请手动指定：
```bash
python audit.py --app-data-dir "C:/Users/your.name/.gemini/antigravity"
```

**Q: Claude Code / Codex 的数据源显示 `❌ N/A`？**

检查对应目录是否存在：
- Claude Code: `C:\Users\<USERNAME>\.claude\projects\`
- Codex: `C:\Users\<USERNAME>\.codex\sessions\`

如果目录不存在说明该工具尚未产生本地会话文件，该数据源将被自动跳过。

**Q: Trae 的 Token 数据为什么是估算的？**

Trae 的本地存储 (`state.vscdb`) 中只记录了会话 Turn 数量，不包含实际 Token 计数。
脚本使用固定比例估算：输入 8,000 Token/Turn，输出 500 Token/Turn。
实际消耗可能与估算有偏差，仅供参考。

**Q: 在 Antigravity 中 Skill 没有自动触发？**

确认 skill 目录路径正确：
```
d:\Temp\shell\quick-shell\.agents\skills\token-insight-report\SKILL.md
```
也可以明确在对话中说：`使用 token-insight-report skill 分析本月的 IDE 数据`。

**Q: 想增加自定义项目关键词？**

编辑 `scripts/audit.py` 顶部的 `PROJECT_KEYWORDS` 字典：
```python
PROJECT_KEYWORDS = {
    "my-project": ["my-project", "MyProject"],   # 新增这一行
    ...
}
```

---

*文档版本：2026-06-05 | Token Insight Report Skill v1.1*
