---
name: token-insight-report
description: >
  Deep-audit IDE usage for Claude Code / Antigravity (and comparable tools like Cursor, Trae, Codex).
  Reads local session transcripts, token_stats.db, and RTK logs to generate a structured monthly/weekly
  efficiency report covering: total active hours, project time distribution, token consumption breakdown,
  error rate analysis, invalid work hours estimate, and user-prompt quality diagnosis.
  Use this skill whenever the user asks to "analyze this month's IDE usage", "audit Claude Code sessions",
  "how many tokens did I use this week", "summarize my AI coding activity", "generate an IDE performance report",
  "诊断报告", "月度IDE复盘", "Token用量分析", or wants to understand their AI pairing efficiency patterns.
  Also use when the user wants to convert raw IDE session logs into actionable improvement suggestions.
---

# Token Insight Report Skill

This skill produces a comprehensive **《IDE 效能与人机协同诊断报告》** from your local
Antigravity (Claude Code) session data. It is designed to run monthly or weekly.

## What this skill does

1. Reads **`token_stats.db`** for precise token consumption metrics (per session, per day).
2. Scans all **`transcript.jsonl`** files under the `brain/` directory to compute:
   - Estimated active development hours (splitting on inactivity gaps)
   - Project time distribution (detected via keyword matching in content)
   - Error step count and error rate
   - User prompt samples for qualitative review
3. Queries **`rtk gain`** for CLI-level token savings statistics.
4. Outputs a structured **Markdown report** (and optional JSON) to an output directory.

## Quick start

```bash
# Run with defaults (last 30 days, auto-detect app data dir)
# Report is written to the CURRENT working directory as token_insight_report_YYYYMMDD.md
python scripts/audit.py

# Custom app data dir, 7-day window
python scripts/audit.py --app-data-dir "C:/Users/cearn/.gemini/antigravity" --days 7

# Specify a custom output directory
python scripts/audit.py --output-dir ./reports/

# Output raw JSON alongside the markdown
python scripts/audit.py --days 30 --json

# Only scan specific sources
python scripts/audit.py --sources antigravity,cursor
```

## How to use this skill

When the user asks for an IDE audit or monthly/weekly token summary:

### Step 1: Run the audit script

Execute (from the project's working directory, or any directory you want the report in):
```bash
python d:\Temp\shell\quick-shell\.agents\skills\token-insight-report\scripts\audit.py \
  --app-data-dir "C:/Users/<USERNAME>/.gemini/antigravity" \
  --days 30
```

Replace `<USERNAME>` with the actual username (check `C:\Users\` or `%USERNAME%` env var).
The script auto-detects if `--app-data-dir` is omitted.

**Output**: The report is saved to the **current working directory** as:
```
token_insight_report_YYYYMMDD.md
```

### Step 2: Read and render the report

The script writes the report to the **current working directory**:
```
<cwd>/token_insight_report_YYYYMMDD.md
```
Read the file and present its contents to the user as a formatted report.

### Step 3: Prompt quality diagnosis (manual)

After showing the token/time stats, perform an additional qualitative pass on the
`user_prompts` samples in the output:

Diagnose each sample prompt using these three lenses:
1. **不清楚 (Ambiguous intent)** — Does the prompt have a clear, single goal?
2. **约束缺失 (Missing constraints)** — Is the OS/env/file path/version specified?
3. **目标不准确 (Wrong target definition)** — Is a process being confused for an end goal?

Quote the exact prompt text, then give a numbered diagnosis.

### Step 4: Generate improvement checklist

Based on the qualitative diagnosis, produce a numbered Action Items list.
All items must be concrete and measurable — no fuzzy words like "improve" or "sometimes".

Example format:
```
- [ ] 单个 Prompt 包含的子任务数量不超过 3 个
- [ ] 每次发起涉及 shell 命令的会话，首条 Prompt 必须声明 OS 类型（Windows/Linux）和 Shell 类型
- [ ] 每当 AI 发生 fuzzy match 失败时，立刻在 Prompt 中提供前后各 5 行精准代码作为锚点
```

## Report structure

The generated report ALWAYS follows this template:

```
# 📊 IDE 效能与人机协同诊断报告
> 分析周期 | 生成时间

## 1. 效能总览
  - 活跃会话数 / Turn 数 / 总时长 / Token 总量 / 缓存命中率 / 错误率 / 无效工时

## 2. 项目时间分布
  - 表格：项目名 / 活跃时长 / 占比

## 3. Token 每日趋势
  - 表格：日期 / 会话数 / Turns / 未缓存输入 / 缓存输入 / 输出 / 合计

## 4. Token 消耗 Top 10 会话
  - 表格：UUID / 标题 / Turns / 总 Token

## 5. 高错误率会话 Top 5
  - 表格：UUID / 项目 / Steps / 错误数 / 错误率 / 活跃时长

## 6. RTK 命令行 Token 节省

## 7. 高活跃会话用户 Prompt 样本
  - 每个 top 会话列出 3 条原始 Prompt
```

## Configuration

The script uses keyword-based project detection. Extend the `PROJECT_KEYWORDS` dict in
`scripts/audit.py` to add your own projects:

```python
PROJECT_KEYWORDS = {
    "my-project": ["my-project", "myproject", "MyProject"],
    ...
}
```

Key tunable parameters (at top of `audit.py`):
| Parameter | Default | Description |
|-----------|---------|-------------|
| `SESSION_GAP_SECONDS` | 1800 | Gap (seconds) to split sessions |
| `SESSION_BUFFER_SECONDS` | 300 | Added per segment as "focus time" buffer |

## Data sources

| Source | Path | Contents |
|--------|------|----------|
| `token_stats.db` | `<app-data>/token_stats.db` | Token counts per turn |
| `transcript.jsonl` | `<app-data>/brain/<uuid>/.system_generated/logs/transcript.jsonl` | Full step-by-step session log |
| `rtk gain` | CLI | Shell command token savings |

## Notes on confidence levels

- **Token statistics** (from `token_stats.db`): **High confidence** — exact counts from DB.
- **Active hours** (from transcripts): **Medium confidence** — heuristic based on timestamp gaps; real focus time may differ.
- **Project assignment**: **Medium confidence** — keyword-based; sessions touching multiple projects may be misattributed.
- **Error rate**: **Medium confidence** — captures `status=ERROR` steps and system error messages; not all errors represent user-visible failures.
