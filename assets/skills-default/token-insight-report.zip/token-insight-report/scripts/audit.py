#!/usr/bin/env python3
"""
Token Insight Report — Multi-Source IDE Audit Script
Supports 6 data sources: Antigravity, Claude Code, Codex CLI, Cursor, Trae, Trae CN

Usage:
    python audit.py [--days N] [--output-dir PATH] [--json] [--sources SOURCE1,SOURCE2]

Sources:
    antigravity  — ~/.gemini/antigravity/  (token_stats.db + transcript.jsonl, HIGH confidence)
    claude_code  — ~/.claude/projects/     (.jsonl events, HIGH confidence)
    codex        — ~/.codex/sessions/      (.jsonl events, HIGH confidence)
    cursor       — AppData/Roaming/Cursor/ (state.vscdb composerData, MEDIUM confidence)
    trae         — AppData/Roaming/Trae/   (state.vscdb ItemTable, LOW confidence — estimated)
    trae_cn      — AppData/Roaming/Trae CN/(state.vscdb ItemTable, LOW confidence — estimated)

Defaults: all available sources, last 30 days.
"""

import argparse
import glob
import json
import os
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path


# ──────────────────────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────────────────────

PROJECT_KEYWORDS = {
    "ai-token-monitor": ["ai-token-monitor", "token_stats", "token-monitor"],
    "superpowers":      ["superpowers"],
    "sky":              ["sky-demo", "IdeaProjects/sky"],
    "VibeCoding":       ["VibeCoding"],
    "quick-shell":      ["quick-shell"],
    "dify":             ["dify"],
    "gallery-dl":       ["gallery-dl"],
    "sky-ai-platform":  ["sky-ai-platform", "sky-guide"],
    "zoe-ai-governance":["zoe-ai-governance"],
}

SESSION_GAP_SECONDS    = 1800  # 30-min gap splits a session segment
SESSION_BUFFER_SECONDS = 300   # buffer added per segment as "focus time"

# Trae token estimation constants (source has no real token data)
TRAE_INPUT_PER_TURN  = 8000
TRAE_OUTPUT_PER_TURN = 500


# ──────────────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────────────

def _safe_decode(text: str) -> str:
    if not text:
        return ""
    for enc in ('utf-8', 'gbk', 'latin1'):
        try:
            return text.encode('latin1').decode(enc)
        except Exception:
            pass
    return text


def _parse_ts(ts_str: str):
    if not ts_str:
        return None
    ts_str = ts_str.rstrip('Z').split('.')[0]
    try:
        return datetime.strptime(ts_str, '%Y-%m-%dT%H:%M:%S')
    except Exception:
        return None


def _in_range(dt, since_dt, until_dt):
    return dt is not None and since_dt <= dt <= until_dt


def _detect_project(text: str) -> str:
    if not text:
        return "Unknown"
    for project, keywords in PROJECT_KEYWORDS.items():
        for kw in keywords:
            if kw.lower() in text.lower():
                return project
    return "Unknown"


def _calc_duration(timestamps: list) -> float:
    """Active seconds from a sorted timestamp list, splitting on 30-min gaps."""
    if not timestamps:
        return 0.0
    total = 0.0
    seg_start = prev = timestamps[0]
    for t in timestamps[1:]:
        if (t - prev).total_seconds() > SESSION_GAP_SECONDS:
            total += (prev - seg_start).total_seconds() + SESSION_BUFFER_SECONDS
            seg_start = t
        prev = t
    total += (prev - seg_start).total_seconds() + SESSION_BUFFER_SECONDS
    return total


def _empty_source(source_id: str, reason: str) -> dict:
    return {
        "source": source_id,
        "available": False,
        "reason": reason,
        "sessions": 0,
        "turns": 0,
        "uncached_input": 0,
        "cached_input": 0,
        "output": 0,
        "total_tokens": 0,
        "confidence": "N/A",
        "daily": [],
        "top_sessions": [],
    }


# ──────────────────────────────────────────────────────────────────────────────
# SOURCE 1: ANTIGRAVITY (token_stats.db + transcript.jsonl)
# ──────────────────────────────────────────────────────────────────────────────

def load_antigravity(app_data_dir: str, since_dt: datetime, until_dt: datetime) -> dict:
    """
    Reads token_stats.db for precise per-turn token counts (uncached/cached/output),
    and transcript.jsonl for active-hour estimates, error analysis, and prompt samples.
    Confidence: HIGH (exact DB counts).
    """
    db_path    = os.path.join(app_data_dir, 'token_stats.db')
    brain_dir  = os.path.join(app_data_dir, 'brain')

    if not os.path.exists(db_path):
        return _empty_source("antigravity", f"token_stats.db not found: {db_path}")

    since_str = since_dt.strftime('%Y-%m-%dT%H:%M:%SZ')
    until_str = until_dt.strftime('%Y-%m-%dT%H:%M:%SZ')

    conn = sqlite3.connect(db_path)
    c    = conn.cursor()

    c.execute("""
        SELECT COUNT(DISTINCT s.uuid), COUNT(t.idx),
               SUM(t.uncached_input), SUM(t.cached_input), SUM(t.output)
        FROM sessions s JOIN turns t ON s.uuid = t.uuid
        WHERE s.created_at >= ? AND s.created_at <= ?
    """, (since_str, until_str))
    row = c.fetchone()
    totals = {
        "sessions":       row[0] or 0,
        "turns":          row[1] or 0,
        "uncached_input": row[2] or 0,
        "cached_input":   row[3] or 0,
        "output":         row[4] or 0,
    }
    totals["total_tokens"] = totals["uncached_input"] + totals["cached_input"] + totals["output"]

    c.execute("""
        SELECT date(s.created_at),
               COUNT(DISTINCT s.uuid), COUNT(t.idx),
               SUM(t.uncached_input), SUM(t.cached_input), SUM(t.output)
        FROM sessions s JOIN turns t ON s.uuid = t.uuid
        WHERE s.created_at >= ? AND s.created_at <= ?
        GROUP BY 1 ORDER BY 1 DESC
    """, (since_str, until_str))
    daily = [
        {"day": r[0], "sessions": r[1], "turns": r[2],
         "uncached_in": r[3] or 0, "cached_in": r[4] or 0, "out": r[5] or 0}
        for r in c.fetchall()
    ]

    c.execute("""
        SELECT s.uuid, s.title, s.created_at, COUNT(t.idx),
               SUM(t.uncached_input), SUM(t.cached_input), SUM(t.output)
        FROM sessions s JOIN turns t ON s.uuid = t.uuid
        WHERE s.created_at >= ? AND s.created_at <= ?
        GROUP BY s.uuid ORDER BY 4 DESC LIMIT 10
    """, (since_str, until_str))
    top_db = [
        {"uuid": r[0], "title": _safe_decode(r[1]), "created_at": r[2],
         "turns": r[3],
         "uncached_in": r[4] or 0, "cached_in": r[5] or 0, "out": r[6] or 0,
         "total": (r[4] or 0) + (r[5] or 0) + (r[6] or 0)}
        for r in c.fetchall()
    ]
    conn.close()

    # ── Transcript pass: active hours, error rate, prompts, project distribution
    transcript_stats = _analyze_antigravity_transcripts(brain_dir, since_dt, until_dt)

    return {
        "source":         "antigravity",
        "available":      True,
        "confidence":     "HIGH",
        **totals,
        "daily":          daily,
        "top_sessions":   top_db,
        "transcript":     transcript_stats,
    }


def _analyze_antigravity_transcripts(brain_dir: str, since_dt: datetime, until_dt: datetime) -> dict:
    if not os.path.exists(brain_dir):
        return {}

    total_secs = 0.0
    project_secs = defaultdict(float)
    total_steps = failed_steps = sessions_analyzed = 0
    session_details = []

    for d in os.listdir(brain_dir):
        tpath = os.path.join(brain_dir, d, '.system_generated', 'logs', 'transcript.jsonl')
        if not os.path.exists(tpath):
            continue

        timestamps, user_prompts, files_touched = [], [], set()
        project_name = "Unknown"
        sess_errors = sess_steps = 0
        sess_created = None

        try:
            with open(tpath, 'r', encoding='utf-8') as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        step = json.loads(line)
                    except Exception:
                        continue

                    sess_steps  += 1
                    total_steps += 1

                    ts = _parse_ts(step.get('created_at'))
                    if ts:
                        timestamps.append(ts)
                        if sess_created is None:
                            sess_created = ts

                    content  = step.get('content', '') or ''
                    detected = _detect_project(content)
                    if detected != "Unknown":
                        project_name = detected

                    status = step.get('status', '')
                    if status == 'ERROR':
                        sess_errors  += 1
                        failed_steps += 1
                    elif step.get('source') == 'SYSTEM' and step.get('type') not in (
                            'CONVERSATION_HISTORY', 'SYSTEM_MESSAGE'):
                        lc = content.lower()
                        if any(k in lc for k in ['error', 'failed', 'invalid', 'not found in %path%']):
                            sess_errors  += 1
                            failed_steps += 1

                    if step.get('type') == 'USER_INPUT':
                        clean = content.split('<ADDITIONAL_METADATA>')[0]
                        clean = clean.replace('<USER_REQUEST>', '').replace('</USER_REQUEST>', '').strip()
                        if clean:
                            user_prompts.append(_safe_decode(clean)[:200])

                    for tc in (step.get('tool_calls') or []):
                        args = tc.get('args') or {}
                        if isinstance(args, str):
                            try:
                                args = json.loads(args)
                            except Exception:
                                args = {}
                        if isinstance(args, dict):
                            for k in ('AbsolutePath', 'TargetFile', 'SearchPath'):
                                v = args.get(k)
                                if v and isinstance(v, str) and ('/' in v or os.sep in v):
                                    files_touched.add(os.path.basename(v.strip('"')))
        except Exception:
            continue

        if not timestamps:
            continue
        if sess_created and not _in_range(sess_created, since_dt, until_dt):
            continue

        timestamps.sort()
        dur = _calc_duration(timestamps)
        total_secs       += dur
        project_secs[project_name] += dur
        sessions_analyzed += 1

        session_details.append({
            "uuid":         d,
            "project":      project_name,
            "created_at":   sess_created.isoformat() if sess_created else None,
            "steps":        sess_steps,
            "errors":       sess_errors,
            "error_rate":   round(sess_errors / sess_steps, 3) if sess_steps else 0,
            "active_hours": round(dur / 3600, 2),
            "user_prompts": user_prompts[:5],
            "files_touched": sorted(files_touched)[:15],
        })

    session_details.sort(key=lambda x: -x.get('active_hours', 0))
    total_hrs    = total_secs / 3600
    error_ratio  = failed_steps / total_steps if total_steps else 0

    return {
        "sessions_analyzed":     sessions_analyzed,
        "total_active_hours":    round(total_hrs, 2),
        "total_steps":           total_steps,
        "failed_steps":          failed_steps,
        "error_ratio_pct":       round(error_ratio * 100, 2),
        "estimated_invalid_hours": round(total_hrs * error_ratio, 2),
        "project_distribution":  {
            p: {"hours": round(s / 3600, 2),
                "pct":   round(s / total_secs * 100, 1) if total_secs else 0}
            for p, s in sorted(project_secs.items(), key=lambda x: -x[1])
        },
        "top_sessions": session_details[:10],
    }


# ──────────────────────────────────────────────────────────────────────────────
# SOURCE 2: CLAUDE CODE  (~/.claude/projects/**/*.jsonl)
# ──────────────────────────────────────────────────────────────────────────────

def load_claude_code(since_dt: datetime, until_dt: datetime) -> dict:
    """
    Parses .jsonl event files from ~/.claude/projects/.
    Extracts token fields (camelCase and snake_case) from 'usage' objects.
    Confidence: HIGH.
    """
    home = Path.home()
    base = home / '.claude' / 'projects'
    if not base.exists():
        return _empty_source("claude_code", f"Directory not found: {base}")

    sessions     = uncached = cached = output = turns = 0
    daily        = defaultdict(lambda: {"sessions": 0, "turns": 0, "uncached_in": 0,
                                        "cached_in": 0, "out": 0})
    top_sessions = []

    for jsonl_path in base.rglob('*.jsonl'):
        file_sessions = file_turns = file_uncached = file_cached = file_out = 0
        file_created  = None

        try:
            with open(jsonl_path, 'r', encoding='utf-8', errors='replace') as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        ev = json.loads(line)
                    except Exception:
                        continue

                    ts = _parse_ts(ev.get('timestamp') or ev.get('created_at'))
                    if ts and not _in_range(ts, since_dt, until_dt):
                        continue
                    if ts and file_created is None:
                        file_created = ts

                    usage = ev.get('usage') or ev.get('message', {}).get('usage', {}) or {}
                    if not usage:
                        # Also try top-level cost fields
                        usage = ev

                    u_in  = (usage.get('input_tokens')              or usage.get('inputTokens')             or 0)
                    c_in  = (usage.get('cache_read_input_tokens')   or usage.get('cacheReadInputTokens')    or
                             usage.get('cache_creation_input_tokens') or usage.get('cacheCreationInputTokens') or 0)
                    u_out = (usage.get('output_tokens')             or usage.get('outputTokens')            or 0)

                    if u_in or u_out:
                        file_turns   += 1
                        file_uncached += u_in
                        file_cached   += c_in
                        file_out      += u_out

        except Exception:
            continue

        if not file_turns:
            continue

        sessions  += 1
        turns     += file_turns
        uncached  += file_uncached
        cached    += file_cached
        output    += file_out
        file_sessions += 1

        day_key = file_created.strftime('%Y-%m-%d') if file_created else 'unknown'
        daily[day_key]["sessions"]    += 1
        daily[day_key]["turns"]       += file_turns
        daily[day_key]["uncached_in"] += file_uncached
        daily[day_key]["cached_in"]   += file_cached
        daily[day_key]["out"]         += file_out

        top_sessions.append({
            "uuid":  str(jsonl_path.stem)[:16],
            "title": str(jsonl_path.parent.name),
            "turns": file_turns,
            "uncached_in": file_uncached,
            "cached_in": file_cached,
            "out": file_out,
            "total": file_uncached + file_cached + file_out,
        })

    top_sessions.sort(key=lambda x: -x["total"])
    daily_list = [
        {"day": k, **v}
        for k, v in sorted(daily.items(), reverse=True)
    ]

    total_tokens = uncached + cached + output
    return {
        "source":        "claude_code",
        "available":     True,
        "confidence":    "HIGH",
        "sessions":      sessions,
        "turns":         turns,
        "uncached_input": uncached,
        "cached_input":   cached,
        "output":         output,
        "total_tokens":   total_tokens,
        "daily":          daily_list,
        "top_sessions":   top_sessions[:10],
    }


# ──────────────────────────────────────────────────────────────────────────────
# SOURCE 3: CODEX CLI  (~/.codex/sessions/*.jsonl)
# ──────────────────────────────────────────────────────────────────────────────

def load_codex(since_dt: datetime, until_dt: datetime) -> dict:
    """
    Parses .jsonl session files from ~/.codex/sessions/.
    Same token field extraction as Claude Code.
    Confidence: HIGH.
    """
    home = Path.home()
    base = home / '.codex' / 'sessions'
    if not base.exists():
        return _empty_source("codex", f"Directory not found: {base}")

    sessions = uncached = cached = output = turns = 0
    daily    = defaultdict(lambda: {"sessions": 0, "turns": 0, "uncached_in": 0,
                                    "cached_in": 0, "out": 0})
    top_sessions = []

    for jsonl_path in base.rglob('*.jsonl'):
        file_turns = file_uncached = file_cached = file_out = 0
        file_created = None

        try:
            with open(jsonl_path, 'r', encoding='utf-8', errors='replace') as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        ev = json.loads(line)
                    except Exception:
                        continue

                    ts = _parse_ts(ev.get('timestamp') or ev.get('created_at'))
                    if ts and not _in_range(ts, since_dt, until_dt):
                        continue
                    if ts and file_created is None:
                        file_created = ts

                    usage = ev.get('usage') or {}
                    u_in  = usage.get('input_tokens')  or usage.get('inputTokens')  or 0
                    c_in  = usage.get('cache_read_input_tokens') or usage.get('cacheReadInputTokens') or 0
                    u_out = usage.get('output_tokens') or usage.get('outputTokens') or 0

                    if u_in or u_out:
                        file_turns    += 1
                        file_uncached += u_in
                        file_cached   += c_in
                        file_out      += u_out
        except Exception:
            continue

        if not file_turns:
            continue

        sessions += 1
        turns    += file_turns
        uncached += file_uncached
        cached   += file_cached
        output   += file_out

        day_key = file_created.strftime('%Y-%m-%d') if file_created else 'unknown'
        daily[day_key]["sessions"]    += 1
        daily[day_key]["turns"]       += file_turns
        daily[day_key]["uncached_in"] += file_uncached
        daily[day_key]["cached_in"]   += file_cached
        daily[day_key]["out"]         += file_out

        top_sessions.append({
            "uuid": str(jsonl_path.stem)[:16],
            "title": str(jsonl_path.name),
            "turns": file_turns,
            "uncached_in": file_uncached,
            "cached_in": file_cached,
            "out": file_out,
            "total": file_uncached + file_cached + file_out,
        })

    top_sessions.sort(key=lambda x: -x["total"])
    total_tokens = uncached + cached + output
    return {
        "source":        "codex",
        "available":     True,
        "confidence":    "HIGH",
        "sessions":      sessions,
        "turns":         turns,
        "uncached_input": uncached,
        "cached_input":   cached,
        "output":         output,
        "total_tokens":   total_tokens,
        "daily":          [{"day": k, **v} for k, v in sorted(daily.items(), reverse=True)],
        "top_sessions":   top_sessions[:10],
    }


# ──────────────────────────────────────────────────────────────────────────────
# SOURCE 4: CURSOR  (AppData/Roaming/Cursor/User/globalStorage/state.vscdb)
# ──────────────────────────────────────────────────────────────────────────────

def load_cursor(since_dt: datetime, until_dt: datetime) -> dict:
    """
    Reads composerData:* keys from cursorDiskKV table.
    Each assistant bubble (type=2) contains tokenCount.inputTokens/outputTokens.
    No cache token data available.
    Confidence: MEDIUM.
    """
    db_path = Path(os.environ.get('APPDATA', '')) / 'Cursor' / 'User' / 'globalStorage' / 'state.vscdb'
    if not db_path.exists():
        return _empty_source("cursor", f"state.vscdb not found: {db_path}")

    sessions = uncached = output = turns = 0
    daily    = defaultdict(lambda: {"sessions": 0, "turns": 0, "uncached_in": 0, "out": 0})
    top_sessions = []

    try:
        conn = sqlite3.connect(str(db_path))
        c    = conn.cursor()
        # Check if cursorDiskKV exists
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='cursorDiskKV'")
        if not c.fetchone():
            conn.close()
            return _empty_source("cursor", "cursorDiskKV table not found in state.vscdb")

        c.execute("SELECT key, value FROM cursorDiskKV WHERE key LIKE 'composerData:%'")
        rows = c.fetchall()
        conn.close()
    except Exception as e:
        return _empty_source("cursor", f"SQLite error: {e}")

    for key, value in rows:
        if not value:
            continue
        try:
            data = json.loads(value)
        except Exception:
            continue

        conversation = data.get('conversation') or data.get('allConversations') or []
        if isinstance(data.get('conversation'), list):
            conversation = data['conversation']

        sess_turns = sess_input = sess_output = 0
        sess_created = None

        for bubble in conversation:
            if not isinstance(bubble, dict):
                continue
            btype = bubble.get('type')
            # type=2 is assistant
            if btype != 2:
                continue

            # Try to get timestamp
            ts_ms = bubble.get('timingInfo', {}).get('clientEndTime') or bubble.get('timestamp')
            if ts_ms:
                try:
                    ts = datetime.fromtimestamp(int(ts_ms) / 1000)
                    if not _in_range(ts, since_dt, until_dt):
                        continue
                    if sess_created is None:
                        sess_created = ts
                except Exception:
                    pass

            tc = bubble.get('tokenCount') or {}
            u_in  = tc.get('inputTokens')  or 0
            u_out = tc.get('outputTokens') or 0

            if u_in or u_out:
                sess_turns  += 1
                sess_input  += u_in
                sess_output += u_out

        if not sess_turns:
            continue

        sessions += 1
        turns    += sess_turns
        uncached += sess_input
        output   += sess_output

        day_key = sess_created.strftime('%Y-%m-%d') if sess_created else 'unknown'
        daily[day_key]["sessions"]    += 1
        daily[day_key]["turns"]       += sess_turns
        daily[day_key]["uncached_in"] += sess_input
        daily[day_key]["out"]         += sess_output

        top_sessions.append({
            "uuid":  key.replace('composerData:', '')[:16],
            "title": data.get('title') or key[:40],
            "turns": sess_turns,
            "uncached_in": sess_input,
            "cached_in": 0,
            "out": sess_output,
            "total": sess_input + sess_output,
        })

    top_sessions.sort(key=lambda x: -x["total"])
    total_tokens = uncached + output
    return {
        "source":        "cursor",
        "available":     True,
        "confidence":    "MEDIUM",
        "note":          "No cache token data in Cursor; only input+output available.",
        "sessions":      sessions,
        "turns":         turns,
        "uncached_input": uncached,
        "cached_input":   0,
        "output":         output,
        "total_tokens":   total_tokens,
        "daily":          [{"day": k, **v} for k, v in sorted(daily.items(), reverse=True)],
        "top_sessions":   top_sessions[:10],
    }


# ──────────────────────────────────────────────────────────────────────────────
# SOURCE 5 & 6: TRAE / TRAE CN  (workspaceStorage/**/state.vscdb)
# ──────────────────────────────────────────────────────────────────────────────

def load_trae(since_dt: datetime, until_dt: datetime, cn: bool = False) -> dict:
    """
    Reads memento/icube-ai-agent-storage from ItemTable in each workspace state.vscdb.
    Only turn count is reliable; tokens are estimated: input=8000/turn, output=500/turn.
    Confidence: LOW.
    """
    source_id  = "trae_cn" if cn else "trae"
    folder     = "Trae CN" if cn else "Trae"
    base       = Path(os.environ.get('APPDATA', '')) / folder / 'User' / 'workspaceStorage'

    if not base.exists():
        return _empty_source(source_id, f"Directory not found: {base}")

    sessions = estimated_input = estimated_output = turns = 0
    daily    = defaultdict(lambda: {"sessions": 0, "turns": 0,
                                    "est_input": 0, "est_output": 0})
    top_sessions = []

    for db_path in base.rglob('state.vscdb'):
        try:
            conn = sqlite3.connect(str(db_path))
            c    = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ItemTable'")
            if not c.fetchone():
                conn.close()
                continue
            c.execute("SELECT value FROM ItemTable WHERE key='memento/icube-ai-agent-storage'")
            row = c.fetchone()
            conn.close()
        except Exception:
            continue

        if not row or not row[0]:
            continue

        try:
            data = json.loads(row[0])
        except Exception:
            continue

        # Extract sessions / turns from Trae's internal structure
        # The storage format is a list of sessions with message arrays
        trae_sessions = data.get('sessions') or data.get('conversations') or []
        if isinstance(data, list):
            trae_sessions = data

        ws_turns = 0
        ws_created = None

        for sess in trae_sessions:
            if not isinstance(sess, dict):
                continue
            msgs = sess.get('messages') or sess.get('turns') or []
            sess_ts_ms = sess.get('createdAt') or sess.get('created_at') or sess.get('timestamp')
            sess_dt = None
            if sess_ts_ms:
                try:
                    sess_dt = datetime.fromtimestamp(int(sess_ts_ms) / 1000)
                    if not _in_range(sess_dt, since_dt, until_dt):
                        continue
                except Exception:
                    pass
            ws_turns += len(msgs)
            if sess_dt and ws_created is None:
                ws_created = sess_dt

        if not ws_turns:
            continue

        sessions          += 1
        turns             += ws_turns
        est_in             = ws_turns * TRAE_INPUT_PER_TURN
        est_out            = ws_turns * TRAE_OUTPUT_PER_TURN
        estimated_input   += est_in
        estimated_output  += est_out

        day_key = ws_created.strftime('%Y-%m-%d') if ws_created else 'unknown'
        daily[day_key]["sessions"]   += 1
        daily[day_key]["turns"]      += ws_turns
        daily[day_key]["est_input"]  += est_in
        daily[day_key]["est_output"] += est_out

        top_sessions.append({
            "uuid": str(db_path.parent.name)[:16],
            "title": str(db_path.parent.name),
            "turns": ws_turns,
            "uncached_in": est_in,
            "cached_in": 0,
            "out": est_out,
            "total": est_in + est_out,
        })

    top_sessions.sort(key=lambda x: -x["total"])
    total_tokens = estimated_input + estimated_output
    return {
        "source":        source_id,
        "available":     True,
        "confidence":    "LOW",
        "note":          f"Tokens estimated: {TRAE_INPUT_PER_TURN}/turn input, "
                         f"{TRAE_OUTPUT_PER_TURN}/turn output. No real token data from Trae.",
        "sessions":      sessions,
        "turns":         turns,
        "uncached_input": estimated_input,
        "cached_input":   0,
        "output":         estimated_output,
        "total_tokens":   total_tokens,
        "daily":          [{"day": k, **v} for k, v in sorted(daily.items(), reverse=True)],
        "top_sessions":   top_sessions[:10],
    }


# ──────────────────────────────────────────────────────────────────────────────
# RTK STATS
# ──────────────────────────────────────────────────────────────────────────────

def load_rtk_stats() -> dict:
    import subprocess
    try:
        result = subprocess.run(
            ['rtk', 'gain'],
            capture_output=True, text=True,
            encoding='utf-8', errors='replace', timeout=15
        )
        out = (result.stdout or '').strip()
        return {"raw_output": out or None, "error": None}
    except FileNotFoundError:
        return {"raw_output": None, "error": "rtk not found in PATH"}
    except Exception as e:
        return {"raw_output": None, "error": str(e)}


# ──────────────────────────────────────────────────────────────────────────────
# REPORT GENERATION
# ──────────────────────────────────────────────────────────────────────────────

CONFIDENCE_BADGE = {"HIGH": "🟢 HIGH", "MEDIUM": "🟡 MEDIUM", "LOW": "🔴 LOW", "N/A": "⚫ N/A"}

def build_report(sources: list[dict], rtk_stats: dict, period_label: str) -> str:
    lines = []
    lines.append("# IDE Token Insight Report")
    lines.append(f"\n> **分析周期**：{period_label}  |  **生成时间**：{datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
    lines.append("---\n")

    # ── 1. Multi-source overview
    lines.append("## 1. 多数据源效能总览\n")
    lines.append("| 数据源 | 可用 | 置信度 | 会话数 | Turns | 总 Token | 缓存命中率 |")
    lines.append("|--------|------|--------|--------|-------|---------|-----------|")

    grand_sessions = grand_turns = grand_total = grand_cached = 0
    available_sources = []

    for s in sources:
        avail  = "✅" if s["available"] else "❌"
        badge  = CONFIDENCE_BADGE.get(s.get("confidence", "N/A"), "N/A")
        total  = s.get("total_tokens", 0)
        cached = s.get("cached_input", 0)
        cache_pct = f"{cached/total*100:.1f}%" if total else "N/A"
        lines.append(
            f"| `{s['source']}` | {avail} | {badge} "
            f"| {s.get('sessions',0):,} | {s.get('turns',0):,} "
            f"| {total:,} | {cache_pct} |"
        )
        if s["available"]:
            grand_sessions += s.get("sessions", 0)
            grand_turns    += s.get("turns", 0)
            grand_total    += total
            grand_cached   += cached
            available_sources.append(s)

    lines.append(f"| **合计** | — | — | **{grand_sessions:,}** | **{grand_turns:,}** | **{grand_total:,}** | {grand_cached/grand_total*100:.1f}% |" if grand_total else "")
    lines.append("")

    # ── 2. Antigravity深度分析（最高精度）
    ag = next((s for s in sources if s["source"] == "antigravity" and s["available"]), None)
    if ag:
        tr = ag.get("transcript", {})
        lines.append("## 2. Antigravity 深度分析\n")
        lines.append("### 2.1 效能指标\n")
        lines.append("| 指标 | 数值 |")
        lines.append("|------|------|")
        lines.append(f"| 总活跃时长（估算）| {tr.get('total_active_hours', 'N/A')} h |")
        lines.append(f"| 错误步骤率 | {tr.get('error_ratio_pct', 'N/A')}% |")
        lines.append(f"| 估算无效工时 | {tr.get('estimated_invalid_hours', 'N/A')} h |")
        lines.append(f"| Token 缓存命中率 | {ag.get('cached_input', 0)/ag.get('total_tokens', 1)*100:.1f}% |")
        lines.append("")

        lines.append("### 2.2 项目时间分布\n")
        proj = tr.get("project_distribution", {})
        if proj:
            lines.append("| 项目 | 活跃时长 | 占比 |")
            lines.append("|------|----------|------|")
            for p, info in proj.items():
                lines.append(f"| {p} | {info['hours']} h | {info['pct']}% |")
        lines.append("")

        lines.append("### 2.3 每日 Token 趋势\n")
        daily = ag.get("daily", [])
        if daily:
            lines.append("| 日期 | 会话数 | Turns | 未缓存输入 | 缓存输入 | 输出 | 合计 |")
            lines.append("|------|--------|-------|-----------|---------|------|------|")
            for d in daily:
                tot = d['uncached_in'] + d['cached_in'] + d['out']
                lines.append(
                    f"| {d['day']} | {d['sessions']} | {d['turns']} "
                    f"| {d['uncached_in']:,} | {d['cached_in']:,} | {d['out']:,} | {tot:,} |"
                )
        lines.append("")

        lines.append("### 2.4 Token 消耗 Top 10 会话\n")
        tops = ag.get("top_sessions", [])
        if tops:
            lines.append("| UUID (前8位) | 标题 | Turns | 总 Token |")
            lines.append("|-------------|------|-------|---------|")
            for s in tops:
                lines.append(
                    f"| `{s['uuid'][:8]}` | {s['title'][:50]} | {s['turns']} | {s['total']:,} |"
                )
        lines.append("")

        lines.append("### 2.5 高错误率会话 Top 5\n")
        err_tops = sorted(
            [s for s in tr.get("top_sessions", []) if s.get("error_rate", 0) > 0],
            key=lambda x: -x.get("error_rate", 0)
        )[:5]
        if err_tops:
            lines.append("| UUID (前8位) | 项目 | Steps | 错误数 | 错误率 | 活跃时长 |")
            lines.append("|-------------|------|-------|-------|--------|---------|")
            for s in err_tops:
                lines.append(
                    f"| `{s['uuid'][:8]}` | {s['project']} | {s['steps']} "
                    f"| {s['errors']} | {s['error_rate']*100:.1f}% | {s['active_hours']} h |"
                )
        lines.append("")

        lines.append("### 2.6 用户 Prompt 样本\n")
        for s in tr.get("top_sessions", [])[:5]:
            prompts = s.get("user_prompts", [])
            if prompts:
                lines.append(f"**会话 `{s['uuid'][:8]}` ({s['project']}, {s['active_hours']}h)：**")
                for p in prompts[:3]:
                    lines.append(f"- `{p[:150]}`")
                lines.append("")

    # ── 3. 其他数据源摘要
    other_sources = [s for s in available_sources if s["source"] != "antigravity"]
    if other_sources:
        lines.append("## 3. 其他 IDE 数据源摘要\n")
        for s in other_sources:
            src   = s["source"]
            badge = CONFIDENCE_BADGE.get(s.get("confidence", "N/A"))
            total = s.get("total_tokens", 0)
            lines.append(f"### {src}  ({badge})\n")
            if s.get("note"):
                lines.append(f"> ⚠️ {s['note']}\n")
            lines.append("| 指标 | 数值 |")
            lines.append("|------|------|")
            lines.append(f"| 会话数 | {s.get('sessions', 0):,} |")
            lines.append(f"| Turns | {s.get('turns', 0):,} |")
            lines.append(f"| 总 Token | {total:,} |")
            lines.append(f"| 未缓存输入 | {s.get('uncached_input', 0):,} |")
            lines.append(f"| 缓存输入 | {s.get('cached_input', 0):,} |")
            lines.append(f"| 输出 | {s.get('output', 0):,} |")
            lines.append("")

            daily = s.get("daily", [])
            if daily:
                lines.append("**每日分布：**\n")
                lines.append("| 日期 | 会话数 | Turns | 估算输入 | 估算输出 |")
                lines.append("|------|--------|-------|---------|---------|")
                for d in daily[:10]:
                    u_in = d.get("uncached_in") or d.get("est_input", 0)
                    u_out = d.get("out") or d.get("est_output", 0)
                    lines.append(f"| {d['day']} | {d['sessions']} | {d['turns']} | {u_in:,} | {u_out:,} |")
                lines.append("")

    # ── 4. RTK
    lines.append("## 4. RTK 命令行 Token 节省\n")
    if rtk_stats.get("raw_output"):
        lines.append("```")
        lines.append(rtk_stats["raw_output"])
        lines.append("```")
    else:
        lines.append(f"_RTK 未安装或未运行：{rtk_stats.get('error', '未知错误')}_")
    lines.append("")

    # ── Footer
    n_ag  = ag.get("transcript", {}).get("sessions_analyzed", 0) if ag else 0
    lines.append("---")
    lines.append(
        f"\n_报告由 token-insight-report skill 自动生成。"
        f"Antigravity：{n_ag} 个会话 transcript；"
        f"可用数据源：{', '.join(s['source'] for s in available_sources)}_"
    )
    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Token Insight Report — Multi-Source IDE Audit")
    parser.add_argument('--app-data-dir', default=None,
                        help='Antigravity app data dir (auto-detected if omitted)')
    parser.add_argument('--days', type=int, default=30,
                        help='Days to look back (default: 30)')
    parser.add_argument('--output-dir', default='.',
                        help='Output directory (default: current directory)')
    parser.add_argument('--json', action='store_true',
                        help='Also save raw data as JSON')
    parser.add_argument('--sources', default=None,
                        help='Comma-separated sources to include (default: all). '
                             'Options: antigravity,claude_code,codex,cursor,trae,trae_cn')
    args = parser.parse_args()

    # Auto-detect app data dir
    username = os.environ.get('USERNAME') or os.environ.get('USER') or 'user'
    app_data = args.app_data_dir or f"C:/Users/{username}/.gemini/antigravity"

    # Time range
    until_dt   = datetime.now()
    since_dt   = until_dt - timedelta(days=args.days)
    period_label = f"{since_dt.strftime('%Y-%m-%d')} ~ {until_dt.strftime('%Y-%m-%d')} (最近 {args.days} 天)"

    enabled = set(args.sources.split(',')) if args.sources else \
              {'antigravity', 'claude_code', 'codex', 'cursor', 'trae', 'trae_cn'}

    print(f"[audit] App data dir : {app_data}")
    print(f"[audit] Period       : {period_label}")
    print(f"[audit] Sources      : {', '.join(sorted(enabled))}")

    sources = []

    if 'antigravity' in enabled:
        print("[audit] Loading Antigravity...")
        sources.append(load_antigravity(app_data, since_dt, until_dt))

    if 'claude_code' in enabled:
        print("[audit] Loading Claude Code...")
        sources.append(load_claude_code(since_dt, until_dt))

    if 'codex' in enabled:
        print("[audit] Loading Codex CLI...")
        sources.append(load_codex(since_dt, until_dt))

    if 'cursor' in enabled:
        print("[audit] Loading Cursor...")
        sources.append(load_cursor(since_dt, until_dt))

    if 'trae' in enabled:
        print("[audit] Loading Trae...")
        sources.append(load_trae(since_dt, until_dt, cn=False))

    if 'trae_cn' in enabled:
        print("[audit] Loading Trae CN...")
        sources.append(load_trae(since_dt, until_dt, cn=True))

    print("[audit] Checking RTK stats...")
    rtk_stats = load_rtk_stats()

    print("[audit] Generating report...")
    report_md = build_report(sources, rtk_stats, period_label)

    os.makedirs(args.output_dir, exist_ok=True)
    ts          = datetime.now().strftime('%Y%m%d')
    report_path = os.path.join(args.output_dir, f"token_insight_report_{ts}.md")
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_md)
    print(f"[audit] Report saved : {report_path}")

    if args.json:
        json_path = os.path.join(args.output_dir, f"token_insight_report_{ts}.json")
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({"period": period_label, "sources": sources}, f,
                      ensure_ascii=False, indent=2, default=str)
        print(f"[audit] JSON data    : {json_path}")

    # Plain-text summary for Windows console
    try:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    except AttributeError:
        pass

    print("\n" + "=" * 60)
    print("== Multi-Source Summary ==")
    for s in sources:
        avail = "OK" if s["available"] else "N/A"
        print(f"  {s['source']:<15} [{avail}] conf={s.get('confidence','?'):<6} "
              f"sessions={s.get('sessions',0):<5} turns={s.get('turns',0):<6} "
              f"tokens={s.get('total_tokens',0):,}")
    print(f"\nFull report: {report_path}")
    return report_path


if __name__ == '__main__':
    main()
